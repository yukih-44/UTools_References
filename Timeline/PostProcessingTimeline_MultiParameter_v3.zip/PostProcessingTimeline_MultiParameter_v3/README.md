# Multi-parameter URP Post Processing Timeline v2

## New in v2

- Every parameter supports Start -> Middle -> End.
- Middle Time controls when the middle value is reached.
- Every new parameter starts with a linear timing curve.
- Adding/removing a Volume override automatically invalidates the cache.
- The clip Inspector includes a Refresh Volume Cache button.
- PropertyCount is derived from the enum Count member.

## Example: 0 -> 1 -> 0

- Start Value: 0
- Middle Value: 1
- End Value: 0
- Middle Time: 0.5
- Timing Curve: Linear

## Refresh behavior

The mixer automatically recaches when:
- the bound Volume changes;
- the Volume Profile reference changes;
- the number of components in the profile changes;
- Refresh Volume Cache is clicked.

The manual button is useful after unusual same-count replacements or editor
situations where the profile contents changed without its count changing.

## Runtime behavior

The tool only writes Volume parameter `.value`.

It never:
- enables camera post-processing;
- enables a Volume;
- sets overrideState;
- activates an override;
- adds missing overrides.

No LINQ, reflection, dictionaries, per-frame allocation, or per-frame TryGet
is used. Profile component count and the integer refresh token are checked each
evaluation; actual TryGet calls occur only when the cache is invalidated.


## v3 changes

- New serialized parameter entries now reliably initialize Middle Time to 0.5.
  Unity can zero-initialize newly added array elements, so this uses a hidden
  one-time initialization flag rather than relying only on a field initializer.
- The clip Inspector shows a warning that the relevant Volume override must
  already exist and have its Override checkbox enabled.
- Timeline still never changes `overrideState`, adds overrides, or activates
  Volume components.
